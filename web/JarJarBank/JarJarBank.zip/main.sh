#!/bin/bash

echo '[+] Starting mariadb...'
service mariadb start

echo '[+] Starting bank application ... '
chmod 755 -R /proc/self/fd/*
# exec gosu challenge java -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:8000 -jar bank-1.0.jar
exec gosu challenge java -jar JarJarBank-1.0.jar
